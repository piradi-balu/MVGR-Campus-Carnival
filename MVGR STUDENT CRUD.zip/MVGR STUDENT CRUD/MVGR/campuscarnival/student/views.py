from django.shortcuts import render, redirect
from .models import *
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods

# Create your views here.

def home(request):
    if request.user.is_authenticated:
        return redirect('students')
    return render(request, 'home.html')

@login_required(login_url='home')
def Students(request):
    if request.method == "POST":
        data = request.POST

        photo = request.FILES.get('photo')
        name = data.get('name')
        description = data.get('description')

        Student.objects.create(
            photo=photo,
            name=name,
            description=description,
        )
        return redirect('students')

    queryset = Student.objects.all()
    if request.GET.get('search'):
        queryset = queryset.filter(name__icontains=request.GET.get('search'))

    context = {'students': queryset}
    return render(request, "students.html", context)


@login_required(login_url='home')
def update_student(request, id):
    queryset = Student.objects.get(id=id)

    if request.method == "POST":
        data = request.POST

        photo = request.FILES.get('photo')
        name = data.get('name')
        description = data.get('description')

        queryset.name = name
        queryset.description = description

        if photo:
            queryset.photo = photo

        queryset.save()
        return redirect('students')

    context = {'student': queryset}
    return render(request, "update.html", context)


@login_required(login_url='home')
def delete_student(request, id):
    queryset = Student.objects.get(id=id)
    queryset.delete()
    return redirect('students')

def logout_page(request):
    logout(request)
    return redirect('home')

def login_page(request):
    if request.user.is_authenticated:
        return redirect('students')
    
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        if not User.objects.filter(username=username).exists():
            messages.error(request, "Invalid Username")
            return render(request, 'home.html', {'show_login_modal': True})
        
        user = authenticate(username=username, password=password)

        if user is None:
            messages.error(request, "Invalid password")
            return render(request, 'home.html', {'show_login_modal': True})
        
        login(request, user)
        return redirect('students')
    
    return render(request, 'home.html')


def register(request):
    if request.user.is_authenticated:
        return redirect('students')
    
    if request.method == "POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = User.objects.filter(username=username)

        if user.exists():
            messages.error(request, "Username already taken")
            return render(request, 'home.html', {'show_register_modal': True})

        user = User.objects.create_user(
            username=username,
            password=password,
            first_name=first_name,
            last_name=last_name
        )

        messages.success(request, "Account created successfully. Please login.")
        return render(request, 'home.html', {'show_login_modal': True})

    return render(request, 'home.html')

