from django.urls import path
from . import views
urlpatterns = [
    path('', views.home, name="home"),
    path('students/', views.Students, name="students"),
    path('delete/<id>/', views.delete_student, name="delete_student"),
    path('update/<id>/', views.update_student, name="update_student"),
    path('login/', views.login_page, name="login"),
    path('register/', views.register, name="register"),
    path('logout/', views.logout_page, name="logout"),
]

